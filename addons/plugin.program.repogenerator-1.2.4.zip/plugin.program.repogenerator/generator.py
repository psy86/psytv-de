#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcgui,xbmcaddon
import sys,os,time
import md5,shutil,zipfile

_addon_ = xbmcaddon.Addon()
_cwd_ = _addon_.getAddonInfo('path').decode('utf-8')
_beispiel_zip_ = os.path.join(_cwd_,'KODI ADDON REPOSETORY BEISPIELE.zip').decode('utf-8')

path_browser =''
if str(_addon_.getSetting('remote_path_off_on')) == 'false':
    path_browser = xbmcgui.Dialog().browse(3,'Pfad zu den gezippten Addons ?','files', '', False, False).decode('utf-8')
    if path_browser == '':
        sys.exit(0)
else:
    path_browser = str(_addon_.getSetting('remote_path')).decode('utf-8')

if not os.path.exists(path_browser) and not os.path.isdir(path_browser):
    sys.exit(0)

def _delete():
    if os.path.isfile(os.path.join(path_browser, "addons.xml")):
        try:
            os.remove(os.path.join(path_browser, "addons.xml"))
        except Exception, e:
            xbmcgui.Dialog().ok('XML file delete error !', str(e))
            sys.exit(1)			
   
    if os.path.isfile(os.path.join(path_browser, "addons.xml.md5")):
        try:
            os.remove(os.path.join(path_browser, "addons.xml.md5"))
        except Exception, e:
            xbmcgui.Dialog().ok('MD5 file delete error !', str(e))
            sys.exit(1)
   
    if os.path.isdir(os.path.join(path_browser, "KODI ADDON REPOSETORY BEISPIELE")):
        try:
            shutil.rmtree(os.path.join(path_browser, "KODI ADDON REPOSETORY BEISPIELE"),ignore_errors=True)
        except Exception, e:
            xbmcgui.Dialog().ok('Repo examples delete error !', str(e))
            sys.exit(1)

    time.sleep(3)

if os.path.exists(path_browser):
    _delete()

    try:
	 
        for file in os.listdir(path_browser):
		
            file = file.decode('utf-8')
			
            if ((os.path.isfile(os.path.join(path_browser,file))) and (file.endswith(".zip"))):

                my_file_name = os.path.basename(file)
			
                if not int(my_file_name.count('-')) > 0:
				
                    i = xbmcgui.Dialog().yesno('Error: ' + my_file_name,'Gezippt = xxxx.xxxx.xxxx-1.0.0.zip','Ungezippt = xxxx.xxxx.xxxx = Mit Addon ID',"\n" + 'Bindestrich Error : Das Format ist Pflicht !','Abbruch','Weiter' )
                    if i == 0:
                        sys.exit(0)
						
                else:

                    new_folder_name = my_file_name[0:int(my_file_name.rfind('-'))]

                    os.makedirs(os.path.join(path_browser,new_folder_name))
                    shutil.move(os.path.join(path_browser,my_file_name), os.path.join(path_browser,new_folder_name,my_file_name))

                    zfile=open(os.path.join(path_browser,new_folder_name,my_file_name),'rb')
                    z=zipfile.ZipFile(zfile)
		
                    for name in z.namelist():

                        if str(os.path.normpath(name)) == str(os.path.join(new_folder_name,'addon.xml')) or str(os.path.normpath(name)) == str(os.path.join(new_folder_name,'fanart.jpg')) or str(os.path.normpath(name)) == str(os.path.join(new_folder_name,'fanart.png')) or str(os.path.normpath(name)) == str(os.path.join(new_folder_name,'icon.jpg')) or str(os.path.normpath(name)) == str(os.path.join(new_folder_name,'icon.png')) or str(os.path.normpath(name)) == str(os.path.join(new_folder_name,'changelog.txt')) and not name.endswith(('\\','/')):

                            outfile = open(os.path.join(path_browser,new_folder_name,os.path.basename(name)),'wb')
                            outfile.write(z.read(name))
                            outfile.close()
							
                    zfile.close()
					
    except Exception, e:
        xbmcgui.Dialog().ok('Structure creator error !', str(e))
        sys.exit(1)
else:
    sys.exit(0)
	
class Generator:

    def __init__( self ):
        self._generate_addons_file()
        self._generate_md5_file()
        
    def _generate_addons_file( self ):

        try:
		
            addons = os.listdir( path_browser )
            addons_xml = u"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<addons>\n"

            for addon in addons:
                gpath = os.path.join(path_browser, addon)

                if not os.path.isdir( gpath ): continue
                _path = os.path.join( gpath, "addon.xml" )
                if not os.path.isfile(_path): continue
				
                xml_lines = open( _path, "r" ).read().splitlines()
                addon_xml = ""
				
                for line in xml_lines:
                    if ( line.find( "<?xml" ) >= 0 ): continue
                    addon_xml += unicode( line.rstrip() + "\n", "utf-8" )

                addons_xml += addon_xml.rstrip() + "\n\n"
				
            addons_xml = addons_xml.strip() + u"\n</addons>\n"
            self._save_addons_file( addons_xml )
			
        except Exception, e:
            xbmcgui.Dialog().ok('Repo generator error !', str(e))
            sys.exit(1)
	
    def _save_addons_file( self, addons_xml ):
        try:
            open( os.path.join(path_browser,"addons.xml"), "w" ).write( addons_xml.encode( "utf-8" ) )
        except Exception, e:
            xbmcgui.Dialog().ok('Addons XML create error !', str(e))
            sys.exit(1)

    def _generate_md5_file( self ):
        try:
            m = md5.new()
        except Exception, e:
            xbmcgui.Dialog().ok('MD5 create error !', str(e))
            sys.exit(1)
        else:
            try:
                m.update(open(os.path.join(path_browser, "addons.xml")).read())
                open(os.path.join(path_browser, "addons.xml.md5"), "w" ).write( m.hexdigest() )
            except Exception, e:
                xbmcgui.Dialog().ok('MD5 create error !', str(e))
                sys.exit(1)

if ( __name__ == "__main__" ):
    Generator()

if str(_addon_.getSetting('repo_example_extract')) == 'false':
    xbmcgui.Dialog().ok('Fertig !', 'Die Kodi Repository Daten wurden erstellt !')
else:
    try:
        z=zipfile.ZipFile(_beispiel_zip_,"r")
        z.extractall(path_browser)
        z.close()
    except Exception, e:
        xbmcgui.Dialog().ok('Repo example extract error !', str(e))
        sys.exit(1)	
    xbmcgui.Dialog().ok('Fertig !', 'Die Kodi Repository Daten und ein,','Kodi Repository Addon Beispiel wurden erstellt !')
#Created by Andre Albus - Loki1979